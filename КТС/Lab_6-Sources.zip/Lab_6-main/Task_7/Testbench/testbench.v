`timescale 1ns/1ns

module testbench;
    // input and output test signals

	reg clk;
	reg [5:0] addr;
	wire [3:0] data_out;
	wire [5:0] addr_out;
	integer i;

    Task_7 dut (clk, addr, data_out, addr_out);
        
    initial 
        begin
            // set initial values of signal
            clk = 1;
            #20; 				// pause
            addr = 6'b000000;	// set address signals value
                for (i=0 ; i<=16; i=i+1)
                begin
                    #20; 			// pause
                    addr = addr+6'b000001;	// set address signals value
                end
        end
        
        //every 10 ns invert clk 
        always #10 clk = ~clk;
        
        initial 
            #380 $finish;
	   

endmodule
