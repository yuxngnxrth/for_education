`timescale 1ns/1ns
module testbench;
    // input and output test signals

	reg [3:0] x;
	wire y;

    Task_3 dut ( x, y );
	
initial 
	begin
		// set inital values of signal
		x = 4'b0000;
	
        repeat(15)
        begin
			#10;                     
			x = x + 4'b0001;	 
        end
	end
	
	initial 
		#160 $finish;

endmodule
