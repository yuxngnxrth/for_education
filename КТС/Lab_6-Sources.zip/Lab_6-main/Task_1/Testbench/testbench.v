`timescale 1ns/1ns
module testbench;
    // input and output test signals

    reg              clk;
    reg     [6:0]    INPUT;
    wire    [3:0]    OUT;


    Task_1 dut ( clk, INPUT, OUT );
    
initial 
    begin
        // set inital values of signal
        clk = 1;
        INPUT = 7'b1001111;
        #5;                     
        
        repeat(3)
        begin
            #20;                     
            INPUT[5:4] = INPUT[5:4]+2'b01;     
        end

        #40; 
        INPUT = 7'b0000000;
        repeat(3)
        begin
            #20;                     
            INPUT[5:4] = INPUT[5:4]+2'b01;     
        end
    end
    
    //every 10 ns invert clk 
    always #10 clk = ~clk;

    
    initial 
        #200 $finish;

endmodule
