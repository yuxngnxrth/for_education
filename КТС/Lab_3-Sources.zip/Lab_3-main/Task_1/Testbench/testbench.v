module testbench;

    // input and output test signals
    reg  [1:0] dut_in;
    wire [9:0] dut_out;

    reg clock = 0;
    // creating the instance of the module we want to test
    //  task_1 - module name
    //  dut  - instance name ('dut' means 'device under test')
    task_1 dut ( dut_in, dut_out );
	
    // do at the beginning of the simulation
    always #5 clock = ~clock; //�������� ������. �������� ������������� ��� ������� ������������.
    initial 
        begin
            dut_in = 2'b00;    // set test signals value
            #10;            // pause
            dut_in = 2'b01;    // set test signals value
            #10;            // pause
            dut_in = 2'b10;    // set test signals value
            #10;            // pause
            dut_in = 2'b11;    // set test signals value
            #10;            // pause
        end

    // do at the beginning of the simulation
    //  print signal values on every change
    initial 
        $monitor("dut_in=%b dut_out;%b", dut_in, dut_out);

    // do at the beginning of the simulation
    initial 
        $dumpvars;  //iverilog dump init

endmodule
