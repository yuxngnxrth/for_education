module dff
(
    input       clk,
    input       xx,
    input       d,
    output reg  q
);

    always @ (posedge clk)
        if (xx)
            q <= d;
 
endmodule