`timescale 1 ns / 100 ps

module testbench;

    reg  xx, n_rst, d;
    wire q;

    dff dut (xx, n_rst, d, q);
    
    initial $dumpvars;

    initial
    begin
        n_rst = 0;
        
        $monitor ("%0d xx %b d %b q %b", $time, xx, d, q);

        # 20;   xx = 0; d = 0; 
        # 20;   xx = 1; d = 0; 
        # 20;   xx = 0; d = 1;
        # 20;   xx = 1; d = 1;
        # 20;   xx = 0; d = 1; n_rst = 1;
        # 20;   xx = 1; d = 1;
        # 20;   xx = 0; d = 0;
        # 20;   xx = 1; d = 0; 
        # 10;   xx = 1; d = 0; 
        # 10;   xx = 0; d = 0;
        # 10;   xx = 0; d = 1; 
        # 10;   xx = 1; d = 1; 
        # 10;   xx = 1; d = 1; n_rst = 0;
        # 10;   xx = 0; d = 1;
        # 10;   xx = 0; d = 1;
        # 10;   xx = 1; d = 1;
        # 10;   xx = 1; d = 0;
        # 20;

        $finish;
    end

endmodule