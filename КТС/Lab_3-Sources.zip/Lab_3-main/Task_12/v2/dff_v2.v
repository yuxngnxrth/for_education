module dff
(
    input       xx,
    input       n_rst,
    input       d,
    output reg  q
);

    always @ (posedge xx)
        if (n_rst)
            q <= d;
 
endmodule
