`timescale 1 ns / 100 ps

module testbench;

    reg  clk, n_rst, xx;
    wire q;

    dff dut (clk, n_rst, xx, q);
    
    initial $dumpvars;

    initial
    begin
        n_rst = 0;
        
        $monitor ("%0d clk %b xx %b q %b", $time, clk, xx, q);

        # 20;   clk = 0; xx = 0; 
        # 20;   clk = 1; xx = 0; 
        # 20;   clk = 0; xx = 1;
        # 20;   clk = 1; xx = 1;
        # 20;   clk = 0; xx = 1; n_rst = 1;
        # 20;   clk = 1; xx = 1;
        # 20;   clk = 0; xx = 0;
        # 20;   clk = 1; xx = 0; 
        # 10;   clk = 1; xx = 0; 
        # 10;   clk = 0; xx = 0;
        # 10;   clk = 0; xx = 1; 
        # 10;   clk = 1; xx = 1; 
        # 10;   clk = 1; xx = 1; n_rst = 0;
        # 10;   clk = 0; xx = 1;
        # 10;   clk = 0; xx = 1;
        # 10;   clk = 1; xx = 1;
        # 10;   clk = 1; xx = 0;
        # 20;

        $finish;
    end

endmodule