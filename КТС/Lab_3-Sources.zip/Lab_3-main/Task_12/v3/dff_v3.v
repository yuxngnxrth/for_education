module dff
(
    input       clk,
    input       n_rst,
    input       xx,
    output reg  q
);

    always @ (posedge clk)
        if (n_rst)
            q <= xx;
 
endmodule
