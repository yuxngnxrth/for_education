
module task_2_v1
(
    input  [1:0] IN,  
    output [9:0] OUT
);

    wire a = ~ IN [0];
    wire b = ~ IN [1];
    assign OUT [0] = a & b;
    assign OUT [1] = ~ a | b;
    assign OUT [2] =  a;
    assign OUT [3] = a ^ b;
    assign OUT [4] = (a | b) & ~ (a & b);
    assign OUT [5] = a ^ 1'b1;
    assign OUT [6] = ~ ( a &   b ) ;
    assign OUT [7] = ~   a |  b   ;
    assign OUT [8] = ~ ( a |   b ) ;
    assign OUT [9] = ~   a &  b   ;
    
endmodule
