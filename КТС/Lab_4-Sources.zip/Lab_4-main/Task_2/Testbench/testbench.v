`timescale 1 ns / 100 ps

module testbench;
    // ������� � �������� �������
    reg  a;
    reg  b;
    reg  sel;
    wire y_comb;
    wire y_sel;
    wire y_if;
    wire y_case;
 
   // ��������� �������
    mux_comb_func mux_comb_func (a, b, sel, y_comb);
    mux_tern mux_tern (a, b, sel, y_sel);
    mux_if mux_if (a, b, sel, y_if);
    mux_case mux_case (a, b, sel, y_case);
    
    initial 
        begin
            a = 1'b0;
            b = 1'b1;
            #5;
            sel = 1'b0;     // sel change to 0; a -> y
            #10;
            sel = 1'b1;     // sel change to 1; b -> y
            #10
            b = 1'b0;       // b change; y changes too. sel == 1'b1
            #5
            b = 1'b1;
            #5;            // pause
        end
    
endmodule