module mux_tern
(
    input  d0,
    input  d1,
    input  sel,
    output y
);

    assign y = sel ? d1 : d0;

endmodule

module mux_if
(
    input  d0,
    input  d1,
    input  sel,
    output reg y
);
    always@(*)
    begin
        if(sel)
            y = d1;
        else 
            y = d0;
    end

endmodule

module mux_case
(
    input  d0,
    input  d1,
    input  sel,
    output reg y
);
    always@(*)
    begin
        case (sel)
            0: y = d0;
            1: y = d1;
        endcase
    end

endmodule