`timescale 1 ns / 100 ps

module testbench;
parameter DATA_CASE_WIDTH = 8;
    // input and output test signals
    	wire  [DATA_CASE_WIDTH-1:0] dout0_case;
	wire  [DATA_CASE_WIDTH-1:0] dout1_case;
    	wire  [DATA_CASE_WIDTH-1:0] dout2_case;
	wire  [DATA_CASE_WIDTH-1:0] dout3_case;
	reg   [1:0] sel;
	reg   [DATA_CASE_WIDTH-1:0] din_case;

	
 
	demux_bn_case #(DATA_CASE_WIDTH) demux_bn_case (.din(din_case), .sel(sel), .dout0(dout0_case), .dout1(dout1_case), .dout2(dout2_case), .dout3(dout3_case));
	
	
	initial 
        begin
			din_case=8'b11111111;
			#5;
            		sel = 2'b00;     // sel change to 00; a -> y
			#10;
			sel = 2'b01;     // sel change to 01; b -> y
			#10
			sel = 2'b10;     // sel change to 10; c -> y
			#10;
			sel = 2'b11;     // sel change to 11; ? -> y
			#10;
			din_case=8'b10101010;
			#10;
			din_case=8'b01010101;
			
			#10;
        end
   
endmodule