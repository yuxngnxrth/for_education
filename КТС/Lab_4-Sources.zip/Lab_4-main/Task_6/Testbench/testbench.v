`timescale 1 ns / 100 ps

module testbench;

    	reg  [1:0] a;
	reg  [1:0] b;
	reg  sel;
    	wire [1:0] y_comb_func;
	wire [1:0] y_tern;
	wire [1:0] y_if;
	wire [1:0] y_case;
 
   	// включение модулей мультиплексоров
	mux_2b_tern mux_2b_tern (a, b, sel, y_tern);
	mux_2b_if mux_2b_if (a, b, sel, y_if);
	mux_2b_case mux_2b_case (a, b, sel, y_case);
	mux_2b_comb_func mux_2b_comb_func (a, b, sel, y_comb_func);
	
	initial 
        begin
			a = 2'b00;
			b = 2'b11;
			#5;
            		sel = 1'b0;     // sel change to 0; a -> y
			#10;
			sel = 1'b1;     // sel change to 1; b -> y
			#10
			b = 2'b10;		// b change; y changes too. sel == 1'b1
			#5
			b = 2'b01;
            		#5;            // pause
        end
  
endmodule