`timescale 1 ns / 100 ps

module testbench;

    	reg  [1:0] a;
	reg  [1:0] b;
    	reg  [1:0] c;
	reg  [1:0] sel;
	wire [1:0] y_casex;

 
	mux_b2_casex mux_b2_casex(a,b,c,sel,y_casex);
	
	initial 
        begin
			a = 2'b00;
			b = 2'b01;
			c = 2'b10;
			#5;
            		sel = 2'b00;     // sel change to 00; a -> y
			#10;
			sel = 2'b01;     // sel change to 01; b -> y
			#10
			sel = 2'b10;     // sel change to 10; c -> y
			#10;
			sel = 2'b11;     // sel change to 11; ? -> y
			#10;
			sel = 2'b00;     // sel change to 00; a -> y
			#10;
			sel = 2'b11;     // sel change to 11; ? -> y
			#10;
        end

endmodule
