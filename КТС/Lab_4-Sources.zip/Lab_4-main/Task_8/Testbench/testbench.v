`timescale 1 ns / 100 ps

module testbench;

    	reg  [1:0] a;
	reg  [1:0] b;
    	reg  [1:0] c;
	reg  [1:0] d;
	reg  [1:0] sel;
	wire [1:0] y_block;

	mux_b2_block_4_to_1 mux_b2_block_4_to_1 (a,b,c,d,sel,y_block);
	
	initial 
        begin
			a = 2'b00;
			b = 2'b01;
			c = 2'b10;
			d = 2'b11;
			#5;
            		sel = 2'b00;     // sel change to 00; a -> y
			#10;
			sel = 2'b01;     // sel change to 01; b -> y
			#10
			sel = 2'b10;     // sel change to 10; c -> y
			#10;
			sel = 2'b11;     // sel change to 11; d -> y
			#10
			d = 2'b10;		// d change; y changes too. sel == 2'b11
			#5
			d = 2'b01;
            		#5;            // pause
        end

endmodule