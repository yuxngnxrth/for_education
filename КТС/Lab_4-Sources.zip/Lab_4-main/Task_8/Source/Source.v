module mux_b2_tern_2_to_1
(
    input  [1:0] d0,
    input  [1:0] d1,
    input        sel,
    output [1:0] y
);

    assign y = sel ? d1 : d0;

endmodule


module mux_b2_block_4_to_1
(
    input  [1:0] d0, d1, d2, d3,
    input  [1:0] sel,
    output [1:0] y
);

    wire [1:0] w01, w23;

    mux_b2_tern_2_to_1 mux0(.d0(d0), .d1(d1), .sel(sel[0]), .y(w01));
    mux_b2_tern_2_to_1 mux1(.d0(d2),.d1(d3), .sel(sel[0]), .y(w23));
    mux_b2_tern_2_to_1 mux2(.d0(w01), .d1(w23), .sel(sel[1]), .y(y));

endmodule
