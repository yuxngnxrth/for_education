// testbench is a module which only task is to test another module
// testbench is for simulation only, not for synthesis
`timescale 1ns/1ns
module testbench;

    reg clock;
    reg reset;
    reg enable;
	reg a;
    wire y;
	wire [1:0] state;

    Task_2 dut (clock, reset, enable, a, y);
    assign state = dut.state;
	
initial 
    begin
        clock = 1;
        reset = 1;
        enable = 1;
		a = 1;
        
        #10; reset = 0;
		repeat (7)
		begin
			enable = 0;
			#20; a = 0;
			enable = 1;
			#20; a = 1;
			#20; 			
		end
    end
    
    always #10 clock = ~clock;

    initial 
        #250 $finish;
    

endmodule