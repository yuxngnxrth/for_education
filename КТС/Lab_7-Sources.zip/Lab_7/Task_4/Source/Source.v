module Task_4
(
    input  clock,
    input  reset,
    input  enable,
    input  a,
    output y
);

    parameter [1:0] S0 = 2'b00, S1 = 2'b01, S2 = 2'b11, S3 = 2'b10;

    reg [1:0] state, next_state;

    always @ (posedge clock or posedge reset)
        if (reset)
            state <= S0;
        else if (enable)
            state <= next_state;

    always @*
        case (state)
        
        S0:
            if (a)
                next_state = S0;
            else
                next_state = S1;

        S1:
            if (a)
                next_state = S1;
            else
                next_state = S2;

        S2:
            if (a)
                next_state = S0;
            else
                next_state = S3;

        S3:
            if (a)
                next_state = S2;
            else
                next_state = S0;

        default:

            next_state = S0;

        endcase

    assign y = (a & state == S1);

endmodule