module Task_1
(
    input  clock,
    input  reset,
    input  enable,
    input  a,
    output y
);

    parameter [1:0] S0 = 0, S1 = 1, S2 = 2;

    reg [1:0] state, next_state;

    always @ (posedge clock or posedge reset)
        if (reset)
            state <= S0;
        else if (enable)
            state <= next_state;

    always @*
        case (state)
        
        S0:
            if (a)
                next_state = S1;
            else
                next_state = S0;

        S1:
            if (a)
                next_state = S2;
            else
                next_state = S1;

        S2:
            if (a)
                next_state = S0;
            else
                next_state = S2;

        default:

            next_state = S0;

        endcase

    assign y = (state == S2 || state == S1);

endmodule
