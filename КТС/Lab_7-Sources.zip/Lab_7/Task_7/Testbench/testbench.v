
`timescale 1ns/1ns
module testbench;

    reg clock;
    reg reset;
    reg enable;
	reg [1:0] a;
    wire [1:0] y;
	wire [1:0] state;

    Task_7 dut (clock, reset, enable, a, y);
    assign state = dut.state;
	
initial 
    begin
        clock = 0;
        reset = 1;
        enable = 1;
		a = 1;
        
        #10; reset = 0;
		repeat (30)
		begin
			enable = 0;
			#20; a = 0;
			enable = 1;
			#20; a = $urandom%3;
			#20; 			
		end
        $finish;
    end
    
    always #10 clock = ~clock;

endmodule